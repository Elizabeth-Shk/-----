﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Simvol_Library;
using Text_Library;


namespace SymbolicTextAnalysis
{
    public partial class Form1 : Form
    {
        private string fn = string.Empty; // имя файла   
        private bool docChanged = false; // true - в текст внесены изменения

        public Form1()
        {
            InitializeComponent();
            this.richTextBox1.Dock = DockStyle.Fill;
            richTextBox1.ScrollToCaret();
            richTextBox1.Text = string.Empty;
            richTextBox1.Font = new Font("Consolas", 12);//очистить текст

            this.Text = "Частотный анализ текста(символьный) - новый докуменит";      //заголовок формы

            // настройка компонента saveDialog1
            saveFileDialog1.DefaultExt = "txt";
            saveFileDialog1.Filter = "текст|*.txt";
            saveFileDialog1.Title = "Сохранить документ";

        }

        // сохранить документ
        private bool SaveDocument()
        {
            bool result = false;
            if (fn == string.Empty)
            {
                // отобразить диалог Сохранить
                if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    // отобразить имя файла в заголовке окна
                    fn = saveFileDialog1.FileName;
                    this.Text = fn;                   
                }
            }
            // сохранить файл
            if (fn != string.Empty)
            {
                try
                {
                    Text_.Save(fn, richTextBox1.Text);
                    result = true;
                }
                catch (Exception exc)
                {
                    MessageBox.Show(exc.ToString(), " Частотный анализ текста(символьный)",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                }
            }
            return result;

        }

        private void сохранитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveDocument();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (docChanged)
            {
                DialogResult dr;
                dr = MessageBox.Show("Сохранить документ?", "Редактор",
                                      MessageBoxButtons.YesNoCancel,
                                      MessageBoxIcon.Warning);
                switch (dr)
                {
                    case DialogResult.Yes:

                        if (SaveDocument())
                        {
                            richTextBox1.Clear();
                            docChanged = false;
                        }
                        else
                        {
                            e.Cancel = true;
                        }
                        break;
                    case DialogResult.No:
                        richTextBox1.Clear();
                        docChanged = false;
                        break;
                    case DialogResult.Cancel:
                        e.Cancel = true;
                        break;
                }
            }
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            docChanged = true;
        }

        private void провестиАнализToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Simvol[] arr = Simvol.AnalysisForAll(richTextBox1.Text);
            new Отчет(arr).ShowDialog();
        }
    }
}
