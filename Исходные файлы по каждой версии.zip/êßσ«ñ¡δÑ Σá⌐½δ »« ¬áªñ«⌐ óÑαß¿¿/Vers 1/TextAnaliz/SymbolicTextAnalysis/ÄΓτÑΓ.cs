﻿using System.Drawing;
using System.Windows.Forms;
using Simvol_Library;

namespace SymbolicTextAnalysis
{
    public partial class Отчет : Form
    {
        public Отчет(Simvol[] arr)
        {
            InitializeComponent();
            for (int i = 1; i < arr.Length; i++)
            {
                dataGridView1.Rows.Add();
            }
            for (int i = 0; i < arr.Length; i++)
            {
                dataGridView1.Rows[i].SetValues(arr[i].Simv, arr[i].Code, arr[i].Count.ToString(), arr[i].OtnCount.ToString("F3") + "%");
            }
            if (arr.Length > 18)
            {
                dataGridView1.Size = new Size(505, 422);
                this.MaximumSize = new Size(545, 500);
                this.MinimumSize = new Size(545, 500);
            }
            else
            {
                dataGridView1.Size = new Size(488, 23 + 22 * arr.Length);
                this.MaximumSize = new Size(530, 23 + 22 * arr.Length + 64);
                this.MinimumSize = new Size(530, 23 + 22 * arr.Length + 64);
            }
        }
    }
}
