﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Simvol_Library
{
    public class Simvol
    {
        public string Simv { get; set; } //Символ
        public int Code { get; private set; } //Код символа
        public int Count { get; private set; } //Количество этого символа в строке
        public double OtnCount { get; private set; } //Относительная частота использования этого символа
        //Конструктор
        public Simvol(char simv, string text)
        {
            Code = Convert.ToChar(simv);
            if (Code < 32 || Code == 127)
            {
                Simv = " ";
            }
            else
            {
                Simv = Convert.ToString(simv);
            }
            Count = text.Length - text.Replace(Convert.ToChar(Code).ToString(), "").Length; ;
            OtnCount = ((double)Count * 100.00) / (double)text.Length; ;
        }
        //Метод для частотного анализа
        public static Simvol[] AnalysisForAll(string text)
        {
            string ContSimv = "";
            List<Simvol> list = new List<Simvol>();
            //Выборка уникальных символов
            for (int i = 0; i < text.Length; i++)
            {
                if (!ContSimv.Contains(text[i]))
                {
                    ContSimv += text[i];
                }
            }
            ContSimv = String.Concat(ContSimv.OrderByDescending(c => c)); //Сортировка символов
            //Частотный анализ
            foreach (char s in ContSimv)
            {
                list.Add(new Simvol(s, text));
            }
            return list.ToArray();
        }
    }
}
