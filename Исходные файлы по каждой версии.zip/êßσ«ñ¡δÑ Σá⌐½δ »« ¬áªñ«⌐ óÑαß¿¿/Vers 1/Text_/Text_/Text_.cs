﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Text_Library
{
    public class Text_
    {
        //Сохранение текста в файл
        public static void Save(string path, string text)
        {
            FileInfo fi = new FileInfo(path);
            StreamWriter sw = fi.CreateText();
            sw.Write(text);
            sw.Close();
        }
    }
}
